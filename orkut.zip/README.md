# 🧡 Taveve API Gateway v2.0 (Ultimate Edition)

![Version](https://img.shields.io/badge/version-2.0-orange.svg?style=for-the-badge) ![Status](https://img.shields.io/badge/status-PRODUCTION-green.svg?style=for-the-badge) ![Node](https://img.shields.io/badge/node-v18%2B-blue.svg?style=for-the-badge) ![License](https://img.shields.io/badge/license-PRIVATE-red.svg?style=for-the-badge)

**Taveve API Gateway** adalah *middleware system* kustom yang dirancang untuk menjembatani komunikasi antara server aplikasi eksternal (bot/web) dengan backend **APP.ORDERKUOTA.COM**. Sistem ini dibangun untuk mengatasi tantangan integrasi pembayaran digital, khususnya QRIS, dengan menyediakan antarmuka API yang terstandarisasi, aman, dan mudah digunakan.

> **⚠️ CORE FUNCTION:** Aplikasi ini melakukan **Emulasi Client HTTP** yang meniru *fingerprint* dan *behavior* dari aplikasi Android asli untuk menghindari deteksi bot dan pemblokiran IP.

---

## 🏗️ System Architecture

Aplikasi ini bekerja sebagai "Middleman" atau Proxy cerdas.

```mermaid
graph LR
    User[Client / Bot / Web] -- HTTP JSON --> Gateway[Taveve API Gateway]
    Gateway -- Emulated Request --> OK[Server OrderKuota]
    OK -- Raw Response --> Gateway
    Gateway -- Formatted JSON --> User
```

**Workflow Utama:**
1.  **Incoming:** Menerima request standar REST API dari client.
2.  **Processing:** Menambahkan Headers, User-Agent, dan Signature Device yang valid.
3.  **Forwarding:** Mengirim request ke API OrderKuota seolah-olah dari HP Android asli.
4.  **Response:** Memproses parsing data (HTML/JSON) dan mengembalikan format bersih ke client.

---

## 🔥 Modules & Features

### 🔐 1. Authentication Module
*   **Request OTP:** Login menggunakan nomor HP/Username untuk memicu pengiriman OTP ke Email.
*   **Verify OTP > Get Token:** Menukar kode OTP menjadi `Auth Token` (Bearer Token).
*   **Session Persistence:** Token dapat digunakan untuk ribuan request selama session di server pusat belum expired.

### 💳 2. Financial Module (QRIS)
*   **Cek Mutasi Otomatis:**
    *   Mengambil history transaksi QRIS.
    *   **Auto-Filter:** Hanya menampilkan transaksi dengan status `IN` (Uang Masuk) untuk mengurangi noise.
    *   **Data Parsing:** Membersihkan raw data tanggal, nominal, dan keterangan pengirim.
*   **Generate Dynamic QRIS:**
    *   **Smart Converter:** Mengubah QRIS Statis (biasa di print di kasir) menjadi QRIS Dinamis.
    *   **Nominal Injection:** Memasukkan tag 'Transaction Amount' (54) ke dalam string QRIS.
    *   **CRC16 Recalculation:** Menghitung ulang *Cyclic Redundancy Check (CRC)* agar QR Code valid dan bisa discan.
*   **QR Decoder (Image to Text):**
    *   Ekstraksi data: Upload file gambar (JPG/PNG) -> Output String QRIS.
    *   Berguna untuk sistem yang butuh input string QRIS tapi sumbernya dari gambar screenshot/foto.

### 🖥️ 3. Dashboard Interface
*   **Teknologi:** HTML5, TailwindCSS (Styling), Alpine.js (Interactivity).
*   **Fitur:**
    *   **Terminal Simulation:** Output response ditampilkan seperti terminal code.
    *   **Dark Mode UI:** Tema "Taveve Orange" (#F5A623) dengan glassmorphism.
    *   **Documentation Tab:** Dokumentasi API interaktif langsung di dashboard.

---

## 🛠️ Technology Stack

| Component | Tech | Description |
| :--- | :--- | :--- |
| **Runtime** | Node.js | v18.0.0+ Recommended |
| **Framework** | Express.js | Lightweight Web Server |
| **HTTP Client** | Axios | Request Handling dengan Custom Agents |
| **Image Process** | Jimp | Image Manipulation untuk QR Decoding |
| **QR Engine** | QRCode + Reader | Encoding & Decoding QR Matrix |
| **File Handling** | Multer | Memory Storage untuk Upload File |
| **Frontend** | Alpine.js | Reactive UI tanpa Build Step |

---

## 📂 Directory Structure

Detail fungsi setiap file dalam project ini:

```
e:\KERJAAN\TAVEVE STORE\orkut\
├── api/
│   └── index.js             # 🚀 Entry Point. Server setup, routing, middleware config.
├── src/
│   ├── config/
│   │   └── settings.js      # ⚙️ KONFIGURASI PENTING. Berisi data dummy device HP.
│   ├── controllers/
│   │   └── apiController.js # 🎮 Logic penghubung antara Route dan Service.
│   ├── services/
│   │   ├── authService.js   # 🔐 Logic Login & Verifikasi ke OrderKuota.
│   │   ├── qrisService.js   # 💰 Logic Mutasi & QR Generator.
│   │   └── qrDecodeService.js # 📷 Logic membaca QR dari gambar buffer.
│   ├── utils/
│   │   ├── qrisLogic.js     # 🧠 Algoritma matematik CRC16 & manipulasi String QR.
│   │   └── response.js      # 📤 Standardisasi format JSON response (success/error).
│   └── views/
│       └── dashboard.js     # 🎨 Frontend Admin Panel (Single File Component).
├── vercel.json              # ☁️ Konfigurasi deployment Serverless (Vercel).
├── package.json             # 📦 Daftar library/dependencies.
└── README.md                # 📄 Dokumentasi ini.
```

---

## 📡 API Documentation (Complete Reference)

Base URL: `http://localhost:3000`

### 1️⃣ Health Check
Memastikan service berjalan dan koneksi ke internet aman.
*   **Method:** `GET`
*   **Endpoint:** `/api/health`
*   **Response:**
    ```json
    { "status": true, "message": "API Gateway healthy...", "api_status": "online" }
    ```

### 2️⃣ Request OTP (Login)
*   **Method:** `POST`
*   **Endpoint:** `/api/auth/login`
*   **Body:**
    ```json
    { "username": "user123", "password": "password123" }
    ```

### 3️⃣ Verify OTP (Dapat Token)
*   **Method:** `POST`
*   **Endpoint:** `/api/auth/verify`
*   **Body:**
    ```json
    { "username": "user123", "otp": "123456" }
    ```
*   **Response Success:**
    ```json
    {
      "status": true,
      "data": {
        "results": {
           "token": "12345:xxxx-auth-token-xxxx",  // <--- SIMPAN INI!
           "balance": "100000"
        }
      }
    }
    ```

### 4️⃣ Cek Mutasi QRIS
*   **Method:** `POST`
*   **Endpoint:** `/api/qris/mutasi`
*   **Body:**
    ```json
    { "auth_username": "user123", "auth_token": "token_dari_step_3" }
    ```

### 5️⃣ Decode QR Image
*   **Method:** `POST`
*   **Endpoint:** `/api/qris/decode`
*   **Headers:** `Content-Type: multipart/form-data`
*   **Body:**
    *   `image`: File gambar (JPG/PNG, Max 5MB)
*   **Response:**
    ```json
    {
      "status": true,
      "data": {
        "qris_string": "000201010211...",
        "filename": "scan.jpg"
      }
    }
    ```

### 6️⃣ Generate Dynamic QR
*   **Method:** `POST`
*   **Endpoint:** `/api/qris/dynamic`
*   **Body:**
    ```json
    {
      "base_string": "000201...", // String dari hasil decode/scan manual
      "amount": 50000             // Nominal rupiah
    }
    ```
*   **Response:**
    ```json
    {
       "data": {
          "dynamic_string": "000201...CRC16",
          "qr_image": "data:image/png;base64,..." // Render ini jadi gambar
       }
    }
    ```

---

## ⚙️ Deep Dive Configuration (`settings.js`)

File `src/config/settings.js` berisi parameter penyamaran. Jika API OrderKuota menolak request (403 Forbidden), biasanya parameter ini perlu diupdate.

```javascript
orderKuota: {
  baseUrl: "app.orderkuota.com",
  userAgent: "okhttp/4.12.0", // Jangan ubah kecuali app update
  device: {
    phone_model: "Infinix X678B", // Bisa diganti tipe HP lain
    phone_uuid: "czmk8Dcr...",    // ID Unik HP. Generate baru jika perlu reset session.
    app_version_name: "26.01.15"  // Wajib match dengan versi app asli terbaru
  }
}
```

---

## ⚠️ Troubleshooting & FAQ

### Q: "Server blocking request" / Time Out?
**Solusi:** IP Address server Anda mungkin kena blacklist sementara oleh firewall mereka.
1.  Restart Router (jika dynamic IP).
2.  Gunakan Proxy Indonesia residential.
3.  Deploy ke VPS dengan IP bersih.

### Q: Token tidak valid saat cek mutasi?
**Solusi:** Token memiliki masa berlaku atau akan hangus jika Anda login di device lain (APP asli).
1.  Jangan login di App OrderKuota HP saat menggunakan Gateway ini.
2.  Lakukan Request OTP & Verify ulang untuk generate token baru.

### Q: QR Code Dynamic tidak bisa discan?
**Solusi:**
1.  Pastikan `base_string` adalah QRIS Statis valid (bukan QRIS dinamis yang sudah expired).
2.  Cek algoritma CRC16 di `src/utils/qrisLogic.js`. Standar QRIS menggunakan CRC16-CCITT (0xFFFF, Poly 0x1021).

---

## 📜 Disclaimer

Software ini dibuat untuk tujuan **Edukasi dan Manajemen Internal** Taveve Store. Penggunaan software ini untuk aktivitas yang melanggar Syarat & Ketentuan pihak ketiga adalah tanggung jawab penuh pengguna.

---

<center>

### **TAVEVE STORE**
*Simplifying Digital Payments*
&copy; 2026 ByDede

</center>
